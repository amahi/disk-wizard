require "disk_wizards/version"
require "disk_wizards/engine"
require "bootstrap-sass.rb"
require "chartkick.rb"
require "disk_command.rb"
require "diskwz.rb"

module DiskWizard
	class Lib
		# the code for your plugin library here
		# or inside lib/disk_wizards/whatever.rb and required here
	end
end
