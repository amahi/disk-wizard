module Wizard
  class Lib
    require "disk_tools/disk_utils"
    require "disk_tools/fstab"
  end
end

