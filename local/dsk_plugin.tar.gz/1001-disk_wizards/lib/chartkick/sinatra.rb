class Sinatra::Base
  helpers Chartkick::Helper
end
