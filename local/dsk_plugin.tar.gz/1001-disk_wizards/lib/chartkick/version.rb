module Chartkick
  VERSION = "1.2.4"
end
