// FIXME: need to use page specific JS
// $(document).ready(function() {
	// setInterval(ajaxd, 2000);
// });
// function ajaxd() {
	// $.ajax({
		// type : "GET",
		// dataType : "json",
		// url : "get_progress",
		// // data : "user=success",
		// success : function(progress) {
			// // alert(progress.message + progress.percentage);
			// $("#progress_message").html(progress.message);
			// if (progress.percentage < 0) {
				// window.location.href = "error";
			// };
		// }
	// });
// }