module ApplicationHelper
  include Chartkick::Helper
end
