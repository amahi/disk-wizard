#! /bin/bash
echo "Start coping ........"
sudo scp -r -i ../disks/id_rsa2.pub /media/data_1/Uni_work/Level3_semester1/gsoc/amahi/amahi_disk_manager/* kbsoft@192.168.0.15:/home/kbsoft/amahi/disk_wizard
