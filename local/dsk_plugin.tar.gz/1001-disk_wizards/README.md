Amahi Disk Wizard(Prototype)
----------------------------
Disk wizard provides a hassle free service to mounting,partitioning,formatting of newly attached storage devices to the HDA.Users are few clicks away from getting there devices ready to work with the system.Wiki page can be found on [here] [1] .Please refer to the New disk wizard wiki page for a more details.  

Demo
----

[See it in action] [2]


[1]: https://wiki.amahi.org/index.php/New_disk_wizard        "here"
[2]: http://amahi.knnect.com/                                "See it in action" 
