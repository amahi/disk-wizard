require 'test_helper'

class DisksHelperTest < ActionView::TestCase
end
