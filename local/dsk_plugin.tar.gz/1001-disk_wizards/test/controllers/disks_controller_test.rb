require 'test_helper'

class DisksControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
