require 'test_helper'

class DiskTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
